from fastapi import FastAPI
from vsDa.lib.logs import log

app = FastAPI()
